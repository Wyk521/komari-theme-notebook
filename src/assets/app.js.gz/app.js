const PINNED_COMMIT = 'e0253c0ed8890ae0ac4547f7fdab122c5b2eecec';
const VERSION = '0.9.0';
const THEME_SHORT = 'KomariNotebook';
const BASES = [
  `https://cdn.jsdelivr.net/gh/Wyk521/komari-theme-notebook@${PINNED_COMMIT}/dist/assets/`,
  `https://raw.githubusercontent.com/Wyk521/komari-theme-notebook/${PINNED_COMMIT}/dist/assets/`
];

const loader = document.getElementById('notebook-loader');
const loaderText = document.getElementById('notebook-loader-text');

function setLoaderMessage(message) {
  if (loaderText) loaderText.textContent = message;
}

async function fetchPinnedAsset(name) {
  let lastError = null;
  for (const base of BASES) {
    try {
      const response = await fetch(`${base}${name}`, { cache: 'no-store', mode: 'cors' });
      if (!response.ok) throw new Error(`${response.status} ${response.statusText}`);
      return await response.text();
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError || new Error(`Unable to load ${name}`);
}

function replaceOnce(source, search, replacement, label) {
  const first = source.indexOf(search);
  if (first < 0) throw new Error(`Patch anchor not found: ${label}`);
  if (source.indexOf(search, first + search.length) >= 0) throw new Error(`Patch anchor is not unique: ${label}`);
  return source.slice(0, first) + replacement + source.slice(first + search.length);
}

function replaceAllChecked(source, search, replacement, label, minimum = 1) {
  const count = source.split(search).length - 1;
  if (count < minimum) throw new Error(`Patch anchor not found: ${label}`);
  return source.split(search).join(replacement);
}

function replaceBetween(source, startMarker, endMarker, replacement, label) {
  const start = source.indexOf(startMarker);
  if (start < 0) throw new Error(`Patch start not found: ${label}`);
  const end = source.indexOf(endMarker, start + startMarker.length);
  if (end < 0) throw new Error(`Patch end not found: ${label}`);
  return source.slice(0, start) + replacement + source.slice(end);
}

function installFieldNotesTooltips() {
  if (document.documentElement.dataset.fieldNotesTooltips === 'ready') return;
  document.documentElement.dataset.fieldNotesTooltips = 'ready';

  const legacy = document.getElementById('hover-tip');
  if (legacy) legacy.hidden = true;

  const tip = document.createElement('div');
  tip.className = 'fieldnotes-hover-tip';
  tip.setAttribute('role', 'tooltip');
  tip.hidden = true;
  document.body.append(tip);

  let active = null;
  const textFor = (target) => String(target?.dataset?.tip || target?.dataset?.tooltip || '').trim();
  const place = (clientX, clientY, target = active) => {
    if (!target || tip.hidden) return;
    const rect = tip.getBoundingClientRect();
    const targetRect = target.getBoundingClientRect();
    const x0 = Number.isFinite(clientX) ? clientX + 12 : targetRect.left + targetRect.width / 2;
    const y0 = Number.isFinite(clientY) ? clientY + 14 : targetRect.bottom + 8;
    const left = Math.max(8, Math.min(window.innerWidth - rect.width - 8, x0));
    const top = Math.max(8, Math.min(window.innerHeight - rect.height - 8, y0));
    tip.style.left = `${left}px`;
    tip.style.top = `${top}px`;
  };
  const show = (target, event) => {
    const text = textFor(target);
    if (!text) return;
    active = target;
    tip.textContent = text;
    tip.hidden = false;
    requestAnimationFrame(() => place(event?.clientX, event?.clientY, target));
  };
  const hide = () => {
    active = null;
    tip.hidden = true;
    tip.textContent = '';
  };

  document.addEventListener('pointerover', (event) => {
    const target = event.target.closest?.('[data-tip],[data-tooltip]');
    if (!target || target.contains(event.relatedTarget)) return;
    show(target, event);
  }, true);
  document.addEventListener('pointermove', (event) => {
    if (active) place(event.clientX, event.clientY);
  }, true);
  document.addEventListener('pointerout', (event) => {
    if (!active || active.contains(event.relatedTarget)) return;
    const leaving = event.target.closest?.('[data-tip],[data-tooltip]');
    if (leaving === active) hide();
  }, true);
  document.addEventListener('focusin', (event) => {
    const target = event.target.closest?.('[data-tip],[data-tooltip]');
    if (target) show(target, null);
  }, true);
  document.addEventListener('focusout', (event) => {
    if (active && active.contains(event.target)) hide();
  }, true);
  window.addEventListener('scroll', hide, { passive: true });
}

function patchApplication(source) {
  const helpers = String.raw`
let rpcRequestId = 0;

function setLiveTransport(transport) {
  document.documentElement.dataset.liveTransport = String(transport || '');
}

function recordLiveError(error) {
  console.warn('[Komari Notebook]', error?.message || String(error || 'Unknown error'));
}

function firstNumber(...values) {
  for (const value of values) {
    if (hasNumber(value)) return Number(value);
  }
  return null;
}

function firstPositiveNumber(...values) {
  for (const value of values) {
    const number = Number(value);
    if (Number.isFinite(number) && number > 0) return number;
  }
  return null;
}

function historyResourcePercent(record = {}, resource, node = {}, live = {}) {
  const raw = record && typeof record === 'object' ? record : {};
  const nested = raw[resource] && typeof raw[resource] === 'object' ? raw[resource] : {};
  const flatUsed = typeof raw[resource] === 'number' || typeof raw[resource] === 'string' ? raw[resource] : null;
  const explicitPercent = firstNumber(
    raw[resource + '_percent'],
    raw[resource + 'Percent'],
    nested.percent,
    nested.usage
  );
  if (explicitPercent !== null) return clamp(explicitPercent);

  const used = firstNumber(
    nested.used,
    flatUsed,
    raw[resource + '_used'],
    resource === 'ram' ? raw.mem_used : null,
    resource === 'ram' ? raw.memory_used : null
  );
  const recordTotal = firstPositiveNumber(
    nested.total,
    raw[resource + '_total'],
    raw[resource + 'Total'],
    resource === 'ram' ? raw.mem_total : null,
    resource === 'ram' ? raw.memory_total : null
  );
  const fallbackTotal = firstPositiveNumber(
    live?.[resource]?.total,
    resource === 'ram' ? node.mem_total : node.disk_total,
    resource === 'ram' ? node.ram_total : null
  );
  const total = recordTotal ?? fallbackTotal;
  if (used === null || total === null) return null;
  return ratio(used, total);
}

function normalizeNodeList(value) {
  if (Array.isArray(value)) return value.filter((node) => node?.uuid);
  if (!value || typeof value !== 'object') return [];
  return Object.entries(value)
    .map(([uuid, node]) => node && typeof node === 'object' ? { ...node, uuid: node.uuid || uuid } : null)
    .filter((node) => node?.uuid);
}

function normalizeLiveRecord(record = {}, node = {}) {
  const raw = record && typeof record === 'object' ? record : {};
  const nestedCpu = raw.cpu && typeof raw.cpu === 'object' ? raw.cpu : {};
  const nestedRam = raw.ram && typeof raw.ram === 'object' ? raw.ram : {};
  const nestedSwap = raw.swap && typeof raw.swap === 'object' ? raw.swap : {};
  const nestedLoad = raw.load && typeof raw.load === 'object' ? raw.load : {};
  const nestedDisk = raw.disk && typeof raw.disk === 'object' ? raw.disk : {};
  const nestedNetwork = raw.network && typeof raw.network === 'object' ? raw.network : {};
  const nestedConnections = raw.connections && typeof raw.connections === 'object' ? raw.connections : {};
  const nestedGpu = raw.gpu && typeof raw.gpu === 'object' ? raw.gpu : null;

  const cpuUsage = firstNumber(
    nestedCpu.usage,
    typeof raw.cpu === 'number' || typeof raw.cpu === 'string' ? raw.cpu : null,
    raw.cpu_usage,
    raw.cpuUsage
  ) ?? 0;
  const ramUsed = firstNumber(
    nestedRam.used,
    typeof raw.ram === 'number' || typeof raw.ram === 'string' ? raw.ram : null,
    raw.ram_used,
    raw.mem_used,
    raw.memory_used
  ) ?? 0;
  const rawRamTotal = firstPositiveNumber(nestedRam.total, raw.ram_total, raw.mem_total, raw.memory_total);
  const ramTotal = rawRamTotal ?? firstPositiveNumber(node.mem_total, node.ram_total) ?? 0;
  const swapUsed = firstNumber(
    nestedSwap.used,
    typeof raw.swap === 'number' || typeof raw.swap === 'string' ? raw.swap : null,
    raw.swap_used
  ) ?? 0;
  const swapTotal = firstPositiveNumber(nestedSwap.total, raw.swap_total, node.swap_total) ?? 0;
  const diskUsed = firstNumber(
    nestedDisk.used,
    typeof raw.disk === 'number' || typeof raw.disk === 'string' ? raw.disk : null,
    raw.disk_used
  ) ?? 0;
  const rawDiskTotal = firstPositiveNumber(nestedDisk.total, raw.disk_total);
  const diskTotal = rawDiskTotal ?? firstPositiveNumber(node.disk_total) ?? 0;
  const flatConnections = typeof raw.connections === 'number' || typeof raw.connections === 'string' ? raw.connections : null;

  return {
    ...raw,
    cpu: { ...nestedCpu, usage: cpuUsage },
    ram: { ...nestedRam, used: ramUsed, total: ramTotal },
    swap: { ...nestedSwap, used: swapUsed, total: swapTotal },
    load: {
      ...nestedLoad,
      load1: firstNumber(nestedLoad.load1, typeof raw.load === 'number' || typeof raw.load === 'string' ? raw.load : null, raw.load1) ?? 0,
      load5: firstNumber(nestedLoad.load5, raw.load5) ?? 0,
      load15: firstNumber(nestedLoad.load15, raw.load15) ?? 0
    },
    disk: { ...nestedDisk, used: diskUsed, total: diskTotal },
    network: {
      ...nestedNetwork,
      up: firstNumber(nestedNetwork.up, raw.net_out, raw.network_up) ?? 0,
      down: firstNumber(nestedNetwork.down, raw.net_in, raw.network_down) ?? 0,
      totalUp: firstNumber(nestedNetwork.totalUp, raw.net_total_up, raw.net_total_out) ?? 0,
      totalDown: firstNumber(nestedNetwork.totalDown, raw.net_total_down, raw.net_total_in) ?? 0
    },
    connections: {
      ...nestedConnections,
      tcp: firstNumber(nestedConnections.tcp, flatConnections, raw.connections_tcp) ?? 0,
      udp: firstNumber(nestedConnections.udp, raw.connections_udp) ?? 0
    },
    gpu: nestedGpu || (hasNumber(raw.gpu) ? { count: 0, average_usage: Number(raw.gpu), detailed_info: [] } : undefined),
    uptime: firstNumber(raw.uptime) ?? 0,
    process: firstNumber(raw.process) ?? 0,
    updated_at: raw.updated_at || raw.time || null
  };
}


function unwrapLivePayload(payload) {
  let current = payload;
  for (let depth = 0; depth < 5; depth += 1) {
    if (!current || typeof current !== 'object') break;
    if (current.result && typeof current.result === 'object') {
      current = current.result;
      continue;
    }
    if (current.status && current.data && typeof current.data === 'object' && !Array.isArray(current.data)) {
      current = current.data;
      continue;
    }
    break;
  }

  if (current && typeof current === 'object' && !Array.isArray(current) && current.data && typeof current.data === 'object') {
    const online = Array.isArray(current.online) ? current.online : null;
    return { records: current.data, online };
  }
  return { records: current, online: null };
}

function recordsToEntries(records) {
  if (Array.isArray(records)) {
    return records.map((record, index) => [String(record?.client || record?.uuid || index), record]);
  }
  if (!records || typeof records !== 'object') return [];
  if (records.client && (hasNumber(records.cpu) || records.cpu?.usage !== undefined)) {
    return [[String(records.client), records]];
  }
  return Object.entries(records);
}

function mergeLivePayload(payload, explicitOnline = null, source = 'unknown') {
  const unwrapped = unwrapLivePayload(payload);
  const records = unwrapped.records;
  const onlineList = explicitOnline || unwrapped.online;
  const entries = recordsToEntries(records);
  if (!entries.length) return false;

  const knownNodes = new Map();
  for (const node of state.nodes) {
    const uuid = String(node.uuid || '').trim();
    if (!uuid) continue;
    knownNodes.set(uuid, node);
    knownNodes.set(uuid.toLowerCase(), node);
  }

  const nextLive = { ...state.live };
  const derivedOnline = new Set();
  let hasOnlineFlag = false;
  let merged = 0;

  for (const [key, rawRecord] of entries) {
    if (!rawRecord || typeof rawRecord !== 'object') continue;
    const candidate = String(rawRecord.client || rawRecord.uuid || key || '').trim();
    const node = knownNodes.get(candidate) || knownNodes.get(candidate.toLowerCase());
    const uuid = String(node?.uuid || candidate).trim();
    if (!uuid) continue;
    nextLive[uuid] = normalizeLiveRecord(rawRecord, node || {});
    merged += 1;
    if (typeof rawRecord.online === 'boolean') {
      hasOnlineFlag = true;
      if (rawRecord.online) derivedOnline.add(uuid);
    }
  }

  if (!merged) return false;
  state.live = nextLive;
  if (Array.isArray(onlineList)) {
    state.online = new Set(onlineList.map((value) => {
      const candidate = String(value || '').trim();
      const node = knownNodes.get(candidate) || knownNodes.get(candidate.toLowerCase());
      return String(node?.uuid || candidate).trim();
    }).filter(Boolean));
  } else if (hasOnlineFlag) {
    state.online = derivedOnline;
  }
  state.liveReady = true;
  state.lastLive = Date.now();
  setLiveTransport(source);
  return true;
}

function rpc2Request(method, params) {
  const request = { jsonrpc: '2.0', method, id: ++rpcRequestId };
  if (params && Object.keys(params).length) request.params = params;
  return request;
}

async function rpc2HttpCall(method, params) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);
  try {
    const response = await fetch('/api/rpc2', {
      method: 'POST',
      credentials: 'same-origin',
      cache: 'no-store',
      headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
      body: JSON.stringify(rpc2Request(method, params)),
      signal: controller.signal
    });
    const payload = await response.json().catch(() => null);
    if (!response.ok) throw new Error(payload?.error?.message || payload?.message || String(response.status) + ' ' + response.statusText);
    if (payload?.error) throw new Error(payload.error.message || 'Komari RPC2 error');
    return payload;
  } finally {
    clearTimeout(timer);
  }
}

function sendRpc2StatusRequest() {
  if (state.rpcSocket?.readyState !== WebSocket.OPEN) return false;
  state.rpcSocket.send(JSON.stringify(rpc2Request('common:getNodesLatestStatus')));
  return true;
}

function connectRpc2() {
  if (DEMO || state.rpcSocket?.readyState === WebSocket.OPEN || state.rpcSocket?.readyState === WebSocket.CONNECTING) return;
  const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
  let socket;
  try {
    socket = new WebSocket(protocol + '//' + location.host + '/api/rpc2');
    state.rpcSocket = socket;
  } catch (error) {
    recordLiveError(error);
    return;
  }

  socket.addEventListener('open', () => {
    if (state.rpcSocket !== socket) return;
    setLiveTransport('RPC2 WS connected');
    sendRpc2StatusRequest();
  });

  socket.addEventListener('message', (event) => {
    if (state.rpcSocket !== socket) return;
    try {
      const payload = JSON.parse(event.data);
      if (payload?.error) throw new Error(payload.error.message || 'Komari RPC2 WebSocket error');
      if (mergeLivePayload(payload, null, 'RPC2 WebSocket')) {
        state.rpcSupported = true;
        setLiveState('open');
        clearFallback();
        scheduleRender();
      }
    } catch (error) {
      recordLiveError(error);
    }
  });

  socket.addEventListener('close', () => {
    if (state.rpcSocket !== socket) return;
    state.rpcSocket = null;
    if (state.rpcSupported !== true) setLiveTransport('RPC2 HTTP fallback');
  });

  socket.addEventListener('error', () => {
    if (state.rpcSocket === socket) recordLiveError(new Error('RPC2 WebSocket connection failed'));
  });
}

async function refreshLatestStatus(silent = false) {
  if (DEMO || state.rpcLoading) return false;
  const sentViaWebSocket = sendRpc2StatusRequest();
  if (sentViaWebSocket && state.rpcSupported === true) return true;
  state.rpcLoading = true;
  try {
    const payload = await rpc2HttpCall('common:getNodesLatestStatus');
    const updated = mergeLivePayload(payload, null, 'RPC2 HTTP');
    if (!updated) return false;
    state.rpcSupported = true;
    setLiveState('open');
    clearFallback();
    if (silent) scheduleRender();
    else render();
    return true;
  } catch (error) {
    recordLiveError(error);
    if (state.rpcSupported === null) state.rpcSupported = false;
    return false;
  } finally {
    state.rpcLoading = false;
  }
}

function startRpcPolling() {
  clearInterval(state.rpcTimer);
  state.rpcTimer = null;
  if (DEMO) return;
  connectRpc2();
  void refreshLatestStatus();
  state.rpcTimer = setInterval(() => {
    connectRpc2();
    void refreshLatestStatus(true);
  }, 2000);
}

`;

  source = replaceOnce(
    source,
    '  socketTimer: null,\n  reconnectTimer: null,',
    '  socketTimer: null,\n  rpcSocket: null,\n  rpcTimer: null,\n  rpcLoading: false,\n  rpcSupported: null,\n  reconnectTimer: null,',
    'state rpc fields'
  );

  source = replaceOnce(
    source,
    'function trafficUsed(node, live) {',
    helpers + 'function trafficUsed(node, live) {',
    'live normalization helpers'
  );

  source = replaceAllChecked(
    source,
    'state.nodes = Array.isArray(nodesResult.value) ? nodesResult.value.filter((node) => node?.uuid) : [];',
    'state.nodes = normalizeNodeList(nodesResult.value);',
    'initial node-list normalization'
  );

  source = replaceAllChecked(
    source,
    'state.nodes = Array.isArray(nodes) ? nodes.filter((node) => node?.uuid) : [];',
    'state.nodes = normalizeNodeList(nodes);',
    'refresh node-list normalization'
  );

  source = replaceOnce(
    source,
    "  dom.summaryTotalDown.textContent = formatBytes(traffic.download);",
    "  dom.summaryTotalDown.textContent = formatBytes(traffic.download);\n  const summaryNetworkLabel = document.getElementById('summary-network-label');\n  const summaryNetworkUpLabel = document.getElementById('summary-network-up-label');\n  const summaryNetworkDownLabel = document.getElementById('summary-network-down-label');\n  if (summaryNetworkLabel) summaryNetworkLabel.textContent = t('network');\n  if (summaryNetworkUpLabel) summaryNetworkUpLabel.textContent = t('upload');\n  if (summaryNetworkDownLabel) summaryNetworkDownLabel.textContent = t('download');\n  document.querySelectorAll('.summary-total-word').forEach((item) => { item.textContent = language === 'zh-CN' ? '累计' : 'Total'; });",
    'summary network labels'
  );

  source = replaceOnce(
    source,
    '  render();\n  connectLive();\n  void refreshPingSummaries();',
    '  render();\n  startRpcPolling();\n  connectLive();\n  void refreshPingSummaries();',
    'initial RPC2 polling'
  );

  source = replaceOnce(
    source,
    "      state.online = new Set(Array.isArray(data?.online) ? data.online : []);\n      state.live = { ...state.live, ...(data?.data && typeof data.data === 'object' ? data.data : {}) };\n      state.liveReady = true;\n      state.lastLive = Date.now();",
    "      if (state.rpcSupported !== true) {\n        mergeLivePayload(data?.data && typeof data.data === 'object' ? data.data : data, Array.isArray(data?.online) ? data.online : null, 'Legacy WebSocket');\n      }",
    'legacy WebSocket normalization'
  );

  source = replaceOnce(
    source,
    '    live[uuid] = latest;',
    "    live[uuid] = normalizeLiveRecord(latest, state.nodes.find((node) => String(node.uuid) === String(uuid)) || {});\n    if (state.rpcSupported !== true) setLiveTransport('Recent-record fallback');",
    'recent-record normalization'
  );

  source = replaceOnce(
    source,
    '      applySettings();\n      if (state.socket?.readyState === WebSocket.OPEN) {',
    '      applySettings();\n      startRpcPolling();\n      if (state.socket?.readyState === WebSocket.OPEN) {',
    'refresh polling interval'
  );

  source = replaceOnce(
    source,
    "      requestLive();\n      if (state.liveState !== 'open') await refreshRecent();",
    "      requestLive();\n      const rpcUpdated = await refreshLatestStatus(true);\n      if (!rpcUpdated && state.liveState !== 'open') await refreshRecent();",
    'manual refresh RPC2 fallback'
  );

  source = replaceOnce(
    source,
    "function scheduleReconnect() {\n  state.retry += 1;",
    "function scheduleReconnect() {\n  if (state.rpcSupported === true) {\n    setLiveState('open');\n    return;\n  }\n  state.retry += 1;",
    'avoid legacy reconnect loop after RPC2 success'
  );


  source = replaceOnce(
    source,
    "function renderCharts(uuid) {\n  const container = document.getElementById('dialog-charts');\n  const entry = state.history.get(uuid);",
    "function renderCharts(uuid) {\n  const container = document.getElementById('dialog-charts');\n  const entry = state.history.get(uuid);\n  const node = state.nodes.find((item) => String(item.uuid) === String(uuid)) || {};\n  const live = state.live[uuid] || {};",
    'history node capacity context'
  );

  source = replaceOnce(
    source,
    "chartCard(t('memoryChart'), [{ name: '', values: loadRecords.map((record) => hasNumber(record.ram) && hasNumber(record.ram_total) ? ratio(record.ram, record.ram_total) : null) }],",
    "chartCard(t('memoryChart'), [{ name: '', values: loadRecords.map((record) => historyResourcePercent(record, 'ram', node, live)) }],",
    'history memory percentage fallback'
  );

  source = replaceOnce(
    source,
    "chartCard(t('diskChart'), [{ name: '', values: loadRecords.map((record) => hasNumber(record.disk) && hasNumber(record.disk_total) ? ratio(record.disk, record.disk_total) : null) }],",
    "chartCard(t('diskChart'), [{ name: '', values: loadRecords.map((record) => historyResourcePercent(record, 'disk', node, live)) }],",
    'history disk percentage fallback'
  );

  source = replaceBetween(
    source,
    'function statusBadge(node) {',
    'function metricRow(label, iconName, value, caption, options = {}) {',
    `function statusBadge(node) {
  const online = isOnline(node);
  const label = t(online === null ? 'waiting' : online ? 'online' : 'offline');
  const mark = online === null ? '…' : online ? '✓' : '×';
  const tone = online === null ? 'waiting' : online ? '' : 'offline';
  return \`<span class="status-badge \${tone}"><i aria-hidden="true">\${mark}</i><span>\${escapeHtml(label)}</span></span>\`;
}

`,
    'field-notes status badge'
  );

  source = replaceBetween(
    source,
    'function metricRow(label, iconName, value, caption, options = {}) {',
    'function segmentTip(segment, type) {',
    `function metricRow(label, iconName, value, caption, options = {}) {
  const normalized = clamp(value);
  const displayValue = options.displayValue || formatPercent(normalized);
  const tone = options.tone === undefined ? metricTone(normalized) : options.tone;
  const tip = \`\${label} \${displayValue} · \${caption}\`;
  return \`<div class="metric-row \${escapeHtml(options.className || '')}">
    <div class="metric-row-head"><span>\${icon(iconName, 13)}<b>\${escapeHtml(label)}</b></span><strong>\${escapeHtml(displayValue)}</strong></div>
    <span class="metric-track" data-tip="\${escapeHtml(tip)}"><span class="metric-fill \${escapeHtml(tone || '')}" style="--value:\${normalized.toFixed(1)}%"></span></span>
    <span class="metric-caption" data-tip="\${escapeHtml(caption)}">\${escapeHtml(caption)}</span>
  </div>\`;
}

`,
    'field-notes metric rows'
  );

  source = replaceBetween(
    source,
    "function qualitySegments(summary, type = 'latency', count = 18) {",
    'function networkPanel(node, live) {',
    `function qualitySegments(summary, type = 'latency', count = 18) {
  const source = Array.isArray(summary?.records) && summary.records.length
    ? buildPingSegments(summary.records, count, 1)
    : Array.isArray(summary?.segments) ? summary.segments : [];
  const segments = source.length === count
    ? source
    : Array.from({ length: count }, (_, index) => source.length ? source[Math.min(source.length - 1, Math.floor((index * source.length) / count))] : null);
  const latencyValues = segments
    .filter((segment) => segment?.count && hasNumber(segment.avg))
    .map((segment) => Number(segment.avg));
  const latencyMin = latencyValues.length ? Math.min(...latencyValues) : 0;
  const latencyMax = latencyValues.length ? Math.max(...latencyValues) : 0;
  const latencySpan = Math.max(1, latencyMax - latencyMin);

  return segments.map((segment) => {
    const value = type === 'loss' ? segment?.loss : segment?.avg;
    const tone = segment?.count ? qualityTone(value, type) : 'empty';
    let height = 18;
    if (segment?.count) {
      if (type === 'latency') {
        const normalized = hasNumber(segment.avg) ? (Number(segment.avg) - latencyMin) / latencySpan : 0;
        height = latencyValues.length > 1 ? 42 + (normalized * 58) : 72;
      } else {
        height = 100;
      }
    }
    return \`<i class="quality-segment \${tone}" style="--bar-height:\${clamp(height, 18, 100).toFixed(0)}%" data-tip="\${escapeHtml(segmentTip(segment, type))}" aria-hidden="true"></i>\`;
  }).join('');
}

function qualityBlock(summary, compact = false) {
  const latency = summary?.avg === null || summary?.avg === undefined ? '—' : formatMilliseconds(summary.avg);
  const loss = summary?.loss === null || summary?.loss === undefined ? '—' : formatPercent(summary.loss, summary.loss > 0 && summary.loss < 10 ? 1 : 0);
  const count = compact ? 10 : 18;
  return \`<div class="quality-block \${compact ? 'is-compact' : ''}">
    <div class="quality-row quality-latency-row">
      <span class="quality-label"><b>\${escapeHtml(t('latency'))}</b><small>\${escapeHtml(latency)}</small></span>
      <span class="quality-strip" style="--segment-count:\${count}">\${qualitySegments(summary, 'latency', count)}</span>
    </div>
    <div class="quality-row quality-loss-row">
      <span class="quality-label"><b>\${escapeHtml(t('packetLoss'))}</b><small>\${escapeHtml(loss)}</small></span>
      <span class="quality-strip" style="--segment-count:\${count}">\${qualitySegments(summary, 'loss', count)}</span>
    </div>
  </div>\`;
}

`,
    'wide low-gap quality bars'
  );

  source = replaceBetween(
    source,
    'function networkPanel(node, live) {',
    'function card(node) {',
    `function networkPanel(node, live) {
  const ping = state.ping[node.uuid];
  const totalLabel = language === 'zh-CN' ? '累计' : 'Total';
  const uploadTip = \`\${t('upload')} \${formatRate(live?.network?.up)} · \${totalLabel} \${formatBytes(live?.network?.totalUp)}\`;
  const downloadTip = \`\${t('download')} \${formatRate(live?.network?.down)} · \${totalLabel} \${formatBytes(live?.network?.totalDown)}\`;

  return \`<section class="node-network-panel">
    <div class="network-panel-head">
      <span class="network-panel-title">\${icon('network', 14)}\${escapeHtml(t('network'))}</span>
      <span class="uptime-inline">\${icon('clock', 12)}\${escapeHtml(formatDuration(live?.uptime))}</span>
    </div>
    <div class="network-ledger">
      <div class="network-ledger-row upload-row" data-tip="\${escapeHtml(uploadTip)}">
        <span class="network-direction"><em>↑</em><b>\${escapeHtml(t('upload'))}</b></span>
        <strong>\${escapeHtml(formatRate(live?.network?.up))}</strong>
        <small>\${escapeHtml(totalLabel)} \${escapeHtml(formatBytes(live?.network?.totalUp))}</small>
      </div>
      <div class="network-ledger-row download-row" data-tip="\${escapeHtml(downloadTip)}">
        <span class="network-direction"><em>↓</em><b>\${escapeHtml(t('download'))}</b></span>
        <strong>\${escapeHtml(formatRate(live?.network?.down))}</strong>
        <small>\${escapeHtml(totalLabel)} \${escapeHtml(formatBytes(live?.network?.totalDown))}</small>
      </div>
    </div>
    \${qualityBlock(ping)}
  </section>\`;
}

`,
    'field-notes compact network ledger'
  );

  source = replaceBetween(
    source,
    'function card(node) {',
    'function tableMeter(value, caption) {',
    `function card(node) {
  const live = state.live[node.uuid];
  const online = isOnline(node);
  const cpu = clamp(live?.cpu?.usage || 0);
  const ramTotal = live?.ram?.total || node.mem_total;
  const diskTotal = live?.disk?.total || node.disk_total;
  const ram = ratio(live?.ram?.used, ramTotal);
  const disk = ratio(live?.disk?.used, diskTotal);
  const traffic = trafficInfo(node, live);
  const remaining = traffic.unlimited ? t('unlimited') : traffic.remaining === null ? '—' : formatBytes(traffic.remaining);
  const remainingPercent = traffic.unlimited ? 100 : traffic.used === null || traffic.limit <= 0 ? 0 : clamp(100 - traffic.percent);
  const trafficCaption = traffic.unlimited
    ? \`\${t('usedTraffic')} \${traffic.used === null ? '—' : formatBytes(traffic.used)}\`
    : \`\${t('usedTraffic')} \${traffic.used === null ? '—' : formatBytes(traffic.used)} / \${formatBytes(traffic.limit)}\`;
  const trafficTone = traffic.unlimited || remainingPercent > 28 ? 'success' : remainingPercent <= 10 ? 'danger' : 'warn';
  const tags = state.settings.show_tags ? splitTags(node.tags).slice(0, 3) : [];
  const group = cleanText(node.group);
  const cpuCaptionParts = [node.cpu_cores ? t('cores', { count: node.cpu_cores }) : null];
  if (state.settings.show_hardware && cleanText(node.cpu_name)) cpuCaptionParts.push(cleanText(node.cpu_name));
  const cpuCaption = cpuCaptionParts.filter(Boolean).join(' · ') || '—';

  return \`<article class="node-card \${online === false ? 'is-offline' : ''}">
    <header class="node-card-header">
      <div class="node-heading">
        <span class="region-mark">\${escapeHtml(node.region || '🖥️')}</span>
        <div class="node-title-block">
          \${group ? '<span class="node-entry-label">' + escapeHtml(group) + '</span>' : ''}
          <h3 class="node-title" title="\${escapeHtml(node.name)}">\${escapeHtml(node.name || t('unknown'))}</h3>
        </div>
      </div>
      <div class="node-header-actions">
        \${statusBadge(node)}
        <button class="detail-button card-detail-button" type="button" data-open-node="\${escapeHtml(node.uuid)}" aria-label="\${escapeHtml(t('details'))}" data-tooltip="\${escapeHtml(t('details'))}">\${icon('chevron', 12)}</button>
      </div>
    </header>
    \${tags.length ? \`<div class="node-tags">\${tags.map((tag) => \`<span class="node-tag"># \${escapeHtml(tag)}</span>\`).join('')}</div>\` : ''}
    <div class="metric-list" aria-label="\${escapeHtml(language === 'zh-CN' ? '资源巡检记录' : 'Resource inspection log')}">
      \${metricRow(t('cpu'), 'cpu', cpu, cpuCaption)}
      \${metricRow(t('memory'), 'memory', ram, formatResourcePair(live?.ram?.used, ramTotal))}
      \${metricRow(t('disk'), 'disk', disk, formatResourcePair(live?.disk?.used, diskTotal))}
      \${metricRow(t('remainingTraffic'), 'gauge', remainingPercent, trafficCaption, { displayValue: remaining, tone: trafficTone, className: 'traffic-metric' })}
    </div>
    \${networkPanel(node, live)}
  </article>\`;
}

`,
    'field-notes node card'
  );


  source = replaceBetween(
    source,
    'function positionOverview(type = state.overviewType) {',
    'function openOverview(type) {',
    `function positionOverview(type = state.overviewType) {
  if (!type) {
    dom.overviewDialog.style.removeProperty('--overview-left');
    dom.overviewDialog.style.removeProperty('--overview-top');
    dom.overviewDialog.style.removeProperty('--overview-width');
    dom.overviewDialog.style.removeProperty('--overview-max-height');
    return;
  }
  const trigger = type === 'asset' ? dom.assetOverviewButton : dom.trafficOverviewButton;
  if (!trigger) return;
  const rect = trigger.getBoundingClientRect();
  const viewportGap = 12;
  const panelWidth = Math.min(440, Math.max(280, innerWidth - viewportGap * 2));
  const left = Math.min(
    innerWidth - panelWidth - viewportGap,
    Math.max(viewportGap, rect.right - panelWidth),
  );
  const top = Math.max(viewportGap, rect.bottom + 9);
  const maxHeight = Math.max(96, innerHeight - top - viewportGap);
  dom.overviewDialog.style.setProperty('--overview-left', \`\${Math.round(left)}px\`);
  dom.overviewDialog.style.setProperty('--overview-top', \`\${Math.round(top)}px\`);
  dom.overviewDialog.style.setProperty('--overview-width', \`\${Math.round(panelWidth)}px\`);
  dom.overviewDialog.style.setProperty('--overview-max-height', \`\${Math.round(maxHeight)}px\`);
}

`,
    'restore anchored overview popover'
  );

  return source;
}

async function boot() {
  try {
    installFieldNotesTooltips();
    document.documentElement.dataset.notebookVersion = VERSION;
    setLoaderMessage('正在铺开作业本纸张与页边线……');
    const css = await fetchPinnedAsset('styles.6afbeb0ae2.css');
    const style = document.createElement('style');
    style.dataset.notebookBaseStyle = 'true';
    style.textContent = css;
    document.head.append(style);
    const polish = document.createElement('link');
    polish.rel = 'stylesheet';
    polish.href = '{{ASSET_BASE}}assets/{{STYLE_FILE}}';
    polish.dataset.notebookStyle = VERSION;
    document.head.append(polish);

    setLoaderMessage('正在整理巡检页与实时数据……');
    const originalSource = await fetchPinnedAsset('app.js');
    const patchedSource = patchApplication(originalSource);

    setLoaderMessage('正在装订节点记录页……');
    const blobUrl = URL.createObjectURL(new Blob([
      patchedSource,
      `\n//# sourceURL=komari-notebook-${VERSION}.js\n`
    ], { type: 'text/javascript' }));
    const script = document.createElement('script');
    script.type = 'module';
    script.src = blobUrl;
    script.addEventListener('load', () => {
      URL.revokeObjectURL(blobUrl);
      document.getElementById('notebook-loading-style')?.remove();
      loader?.remove();
    }, { once: true });
    script.addEventListener('error', () => {
      URL.revokeObjectURL(blobUrl);
      setLoaderMessage('The patched application module failed to start.');
    }, { once: true });
    document.body.append(script);
  } catch (error) {
    console.error('[Komari Notebook]', error);
    setLoaderMessage(`主题加载失败：${error?.message || String(error)}。请检查服务器网络是否可访问 jsDelivr 或 GitHub Raw。`);
    if (loader) loader.style.background = '#fff1f0';
  }
}

void boot();
